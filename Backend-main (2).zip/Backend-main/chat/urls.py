from django.urls import path

from .views import *

urlpatterns = [
    # path('<str:title>/send/', ChatView.as_view()),
    # path('<str:title>/retrieve/', ChatView.as_view()),
    
    # path('<str:room_name>/', chat_room, name='chat_room'),

]